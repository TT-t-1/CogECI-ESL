# 采用用户指定的 CGL 梯度修复

2026-11-04，用户明确指定采用侧边聊天提供的 `CogECI_cgl_gradient_fix.patch`。这条新约定覆盖此前“保留原仓库 CGL 和优化器行为”的设置；其他已约定的数据、模型和实验范围继续执行。

## 实际改动与来源

侧边补丁原样保留为服务器 `user_selected_cgl_gradient_fix.patch`。因服务器已有数据适配与实验参数，按补丁语义合入独立代码副本，而不是直接覆盖作者源文件。

1. 保留 BCEWithLogitsLoss，将连续余弦分数作为 logits，移除损失前的硬比较，使选句监督可反向传播。
2. focal 和 CE 分类设置都加入上下文损失，删除原 CE 分支重复加分类损失的行为。
3. 优化器覆盖所有模型参数，BERT 仍单独使用 2e-5，其余模块 1e-4。

以上是用户选定的修正实现，与作者原始训练代码、论文中 softmax 后硬阈值化的描述不同。它验证了上下文监督能够生效，不保证复现论文相同的数值。

代码：`/home/dancer/tu/cogeci-reproduction/repo-priority/CogECI-cgl-fixed`。
合入后的差异：`cgl_gradient_fix_integrated.patch`。
原始行为副本 `CogECI`、旧运行日志和父目录 Qwen-plus 结果保留。

## 验证

复用侧边聊天的真实 `loop_prediction` 与优化器参数分组检查，并针对合入后的代码重新执行：

- focal／CE 下上下文梯度非零；改变选句标签会改变 linear3 梯度。
- 参数分组无重复、覆盖全部参数；执行一步后 linear3、inter_CGE、GraphConv 参数确实改变。
- GPU1 完整小规模训练、验证、保存、重载通过，重载后的预测一致。
- 使用真实 MAVEN 最大事件对×句子数文档（5,886对、40句）反向通过，但原展开实现加上 Adam 状态后发生显存溢出。

因此额外做了一项**本次3090显存适配**：将事件对×句子×768的展开余弦计算改为归一化向量的矩阵乘法，保留相同的连续CGL目标。float32分数最大差约1.79e-7，float64约8.33e-17；包含零向量的分数、梯度对照均在浮点误差范围内一致。无需量化、截断或减少事件对。

适配后，同一最大文档加上真实 Adam 状态的前向、反向、参数更新全部通过，峰值 allocated 显存8,046,639,616字节，约7.5GiB；无温度停机。侧边补丁的梯度、标签变化和参数更新验证也重新通过。

这些检查使用小张量或合成上下文标签，均不是完整论文实验指标。包含 Adam 状态的适配后实际训练步骤检查记录于 `runs-cgl-fixed/maven_optimizer_smoke`，分数／梯度对照见 `runs-cgl-fixed/cosine_equivalence.json`。

## 实验与数据处理

主实验使用 Llama-3-8B-Instruct，覆盖 ESL、MAVEN；Qwen2.5-7B-Instruct 运行 ESL 模型比较。ESL 继续组件消融、β、SGM层数与图算子比较。沿用30 epochs、seed209、ESL文档五折、固定dev等约定。

此补丁删除训练硬阈值，因此原来的0.1／0.5阈值扫描不再产生不同训练目标，标为“不适用”，不重复运行相同训练。

原有伪标签可复用，训练必须使用修正版重新开始。新的标签处理沿用仓库行为：不能解析为整数列表时记为 `None`，对应全零上下文；越界整数不对应任何句子，忽略并审计。保留全部原始回答，不补括号、不猜改句号；之前严格校验产生的重采样记录也保留，但导出标签使用原始回答。

实际格式失败样例 `train/3_11/pair/40` 的原回答缺少右括号，按原生成脚本语义导出 `None`。真实缓存703条原始上下文回答的回放检查已确认这一处理，并核对 `[9,11]` 在11句文档中只将句9置1。

数据数量、模型版本、BF16本地生成、MAVEN适配及缺失的 `sen_more`、共享DSCRM、图算子等此前已说明的补充选择仍沿用原实施记录。

## 运行和结果目录

- 入口：`scripts/pipeline_cgl_fixed.py --model qwen7b` 或 `--model llama8b`。
- 状态：`qwen7b_cgl_fixed_pipeline_status.json`、`llama8b_cgl_fixed_pipeline_status.json`。
- 所有新阶段日志／训练结果：`runs-cgl-fixed/`。
- 生成记录共用：`labels/<模型>/<数据集>/full/responses.jsonl`。
- 新报告：`results_cgl_fixed.json`、`RESULTS_cgl_fixed.md`，不会混入旧版本成绩。
- GPU1通过同一把文件锁排队；每10秒检查温度，达到85°C只停止本任务，不自动恢复。

两款原版模型均已从公开分发源下载，并通过官方固定提交的文件／Git LFS身份及完整文件哈希校验。论文参考分数继续只作参考，尚未完成的新训练不会被标为复现成功。
