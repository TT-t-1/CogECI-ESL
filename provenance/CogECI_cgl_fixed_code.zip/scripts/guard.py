"""Run one GPU 1 task with continuous temperature monitoring."""
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

run_dir = Path(sys.argv[1]).resolve()
command = sys.argv[2:]
run_dir.mkdir(parents=True, exist_ok=True)

def temperature():
    return int(subprocess.check_output([
        'nvidia-smi', '-i', '1', '--query-gpu=temperature.gpu',
        '--format=csv,noheader,nounits'], text=True).strip())

baseline = temperature()
if baseline >= 85:
    raise SystemExit('GPU 1 at or above 85 C; task was not started')
environment = os.environ.copy()
environment.update(CUDA_VISIBLE_DEVICES='1', TOKENIZERS_PARALLELISM='false', OMP_NUM_THREADS='4')
(run_dir / 'command.json').write_text(json.dumps({'argv': command, 'gpu': 1, 'baseline_c': baseline}, indent=2))
with (run_dir / 'task.log').open('a') as log, (run_dir / 'temperature.csv').open('a') as monitor:
    process = subprocess.Popen(command, env=environment, stdout=log, stderr=subprocess.STDOUT,
                               start_new_session=True)
    (run_dir / 'pid').write_text(str(process.pid))
    monitor.write('unix_time,gpu,temperature_c,task_pid\n')
    stopped = False
    try:
        while process.poll() is None:
            temp = temperature()
            monitor.write(f'{time.time()},1,{temp},{process.pid}\n')
            monitor.flush()
            if temp >= 85:
                stopped = True
                os.killpg(process.pid, signal.SIGTERM)
                break
            time.sleep(10)
    finally:
        if process.poll() is None:
            if not stopped:
                os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
        code = process.wait()
        (run_dir / 'status.json').write_text(json.dumps({'exit_code': code, 'thermal_stop': stopped}))
raise SystemExit(code if code >= 0 else 1)
