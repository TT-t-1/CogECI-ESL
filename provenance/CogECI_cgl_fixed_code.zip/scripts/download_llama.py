"""Download the same original Llama3-8B via its public ModelScope distribution."""
import os
import sys
from pathlib import Path

script = Path(__file__).with_name('download_models.py')
os.execv(sys.executable, [sys.executable, '-u', str(script), '--model', 'llama8b'])
