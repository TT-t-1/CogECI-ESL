"""Check the actual loss loop and optimizer groups with small CPU tensors."""
import ast
import json
from types import SimpleNamespace
import torch
from torch import nn
from torch.nn import functional as F

torch.set_num_threads(1)

def parts(source):
    tree = ast.parse(source)
    focal = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'focal_loss')
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'bertCSRModel')
    loop = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'loop_prediction')
    namespace = {'torch': torch, 'nn': nn, 'F': F}
    exec(compile(ast.Module(body=[focal, loop], type_ignores=[]), 'model.py', 'exec'), namespace)
    return namespace['focal_loss'], namespace['loop_prediction']

class Graph(nn.Module):
    def __init__(self):
        super().__init__()
        self.proj = nn.ModuleDict({'event': nn.Linear(4, 4)})

class Fixture(nn.Module):
    def __init__(self, source, loss_type):
        super().__init__()
        focal, loop = parts(source)
        self.loop_prediction = loop.__get__(self)
        self.pretrained_model, self.GraphConv = nn.Linear(4, 4), nn.Linear(4, 4)
        self.mlp, self.inter_mlp = nn.Linear(12, 2), nn.Linear(12, 2)
        self.CGE, self.inter_CGE = Graph(), Graph()
        self.linear3 = nn.Linear(8, 4)
        self.focal_loss, self.ce_loss = focal(gamma=2, num_classes=2), nn.CrossEntropyLoss()
        self.bce_loss = nn.BCEWithLogitsLoss()
        self.loss_type, self.threshold, self.min_iteration = loss_type, 2, 2
        self.device = torch.device('cpu')

    def get_graphedge_index(self, *args):
        return {}

    def Contrast_pre(self, *args):
        return 0

def forward(model, labels):
    events = model.pretrained_model(torch.arange(12, dtype=torch.float32).view(3, 4) / 10)
    sentences = model.GraphConv(model.pretrained_model(torch.arange(16, dtype=torch.float32).view(4, 4) / 10))
    pair_embedding = torch.cat([events[[0, 1]], events[[1, 2]]], dim=1)
    context = []
    hook = model.bce_loss.register_forward_hook(lambda module, inputs, result: context.append(result))
    losses = []
    for kind in ['intra', 'inter']:
        _, loss = model.loop_prediction(0, 2, 2, [(0, 1), (1, 2)], events, torch.tensor([1, 0]),
                                       [[0, 1]], 0., pair_embedding, labels, sentences, events, kind)
        losses.append(loss)
    hook.remove()
    return sum(losses), sum(context)

labels = torch.tensor([[1., 0., 1., 0.], [0., 1., 0., 0.]])
checks = []
for loss_type in ['focal', 'ce']:
    torch.manual_seed(17)
    _, old_context = forward(Fixture(sources['original_model'], loss_type), labels)
    assert not old_context.requires_grad
    torch.manual_seed(17)
    model = Fixture(sources['fixed_model'], loss_type)
    loss, context = forward(model, labels)
    gradient = torch.autograd.grad(context, model.linear3.weight, retain_graph=True)[0]
    assert torch.isfinite(gradient).all() and gradient.abs().sum() > 0
    _, changed_context = forward(model, 1 - labels)
    changed = torch.autograd.grad(changed_context, model.linear3.weight)[0]
    assert not torch.allclose(gradient, changed)
    names = {'no_decay', 'other_parameters', 'optimizer_grouped_parameters'}
    nodes = [n for n in ast.walk(ast.parse(sources['fixed_main'])) if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id in names for t in n.targets)]
    namespace = {'model': model, 'args': SimpleNamespace(weight_decay=0., t_lr=.01)}
    exec(compile(ast.Module(body=sorted(nodes, key=lambda n: n.lineno), type_ignores=[]), 'main.py', 'exec'), namespace)
    groups = namespace['optimizer_grouped_parameters']
    parameters = [p for group in groups for p in group['params']]
    assert len(parameters) == len({id(p) for p in parameters})
    assert {id(p) for p in parameters} == {id(p) for p in model.parameters()}
    optimizer = torch.optim.AdamW(groups, lr=.01)
    tracked = {n: p.detach().clone() for n, p in model.named_parameters()
               if n in ['linear3.weight', 'inter_CGE.proj.event.weight', 'GraphConv.weight']}
    loss.backward()
    optimizer.step()
    assert all(not torch.equal(before, dict(model.named_parameters())[n]) for n, before in tracked.items())
    checks.append({'loss_type': loss_type, 'context_gradient_nonzero': True,
                   'labels_change_gradient': True, 'optimizer_covers_all_parameters': True,
                   'parameters_updated': list(tracked)})
print(json.dumps({'test': 'actual loop and parameter groups; small CPU tensors', 'checks': checks}, indent=2))
