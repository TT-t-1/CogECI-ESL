"""Apply bounded runtime/observability changes to the pinned pristine repository."""
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
repo = root / 'CogECI'
shutil.copyfile(root.parent / 'iLIF/utils.py', repo / 'utils.py')

def edit(file, old, new):
    path = repo / file
    text = path.read_text()
    assert text.count(old) == 1, (file, old[:100], text.count(old))
    path.write_text(text.replace(old, new))

# Concrete initialization failure: SuperGAT calls this class's reset before proj exists.
edit('model/myGraph.py', 'class my_CGEConv(SuperGATConv):', 'class my_CGEConv(MessagePassing):')
edit('model/myGraph.py', "super().__init__(in_channels['event'],out_channels,aggr='add', **kwargs)",
     "super().__init__(aggr='add', node_dim=0, **kwargs)")

edit('parameter.py', '    args = parser.parse_args()', '''    parser.add_argument('--run_dir', required=True)
    parser.add_argument('--context_beta', type=float, default=6.0)
    parser.add_argument('--sgm_layers', type=int, default=2)
    parser.add_argument('--no_sgm', action='store_true')
    parser.add_argument('--shared_dscrm', action='store_true')
    parser.add_argument('--context_threshold', default='1/n', choices=['1/n', '0.1', '0.5'])
    parser.add_argument('--graph_encoder', default='gat', choices=['gat', 'gcn', 'hypergraph', 'transformer'])
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()''')
edit('model/model.py', '        self.device = args.device', '''        self.device = args.device
        self.context_beta = args.context_beta
        self.no_sgm = args.no_sgm
        self.shared_dscrm = args.shared_dscrm
        self.context_threshold = args.context_threshold''')
edit('model/model.py', '                                        layers=2)', '                                        layers=args.sgm_layers)')
edit('model/model.py', '        sent_embed = sent_embed.unsqueeze(1).repeat(1, 105, 1)',
     '        sent_embed = sent_embed.unsqueeze(1).repeat(1, enc_input_ids.shape[1], 1)')
edit('model/model.py', '        sent_emb = sent_embed + sent_emb',
     '        sent_emb = sent_emb if self.no_sgm else sent_embed + sent_emb')
edit('model/model.py', '        # 分开', '''        if self.shared_dscrm:
            prediction, shared_loss = self.loop_prediction(
                0, max_iteration, self.threshold, event_pairs, event_embed, target, rel_type,
                0.0, event_pair_embed, all_senlable, yuan_sent_emb, yuan_event_embed, type='all')
            return shared_loss, prediction
        # 分开''')
# The shared ablation uses the optimized intra branch. Full-model default is unchanged.
edit('model/model.py', "        if type == 'intra':", "        if type in ('intra', 'all'):")
edit('model/model.py', '        w = 6', '        w = self.context_beta')
edit('model/model.py', '            flag=float(1/cosine_sim.size(1))',
     "            flag = 1 / cosine_sim.size(1) if self.context_threshold == '1/n' else float(self.context_threshold)")
# Intentionally retain the duplicated sent_ground append, thresholded BCE, optimizer membership.

# Optional paper graph comparisons. Keep the original GAT untouched in default experiments.
edit('model/model.py', '        self.linear = nn.Linear(3072, 2304)', '''        if args.graph_encoder != 'gat':
            from .graph_variant import GraphVariant
            self.CGE = GraphVariant(args)
            self.inter_CGE = GraphVariant(args)
        self.linear = nn.Linear(3072, 2304)''')

# Fail on missing pseudolabels and verify pair ordering; no silent zero-label fallback.
edit('data/process_esc_csr.py', 'import os\n', 'import os\nimport ast\n')
edit('data/process_esc_csr.py', "        if type == 'train':", '''        if type == 'test':
            base = os.path.dirname(self.llm_file_dev)
            llm_file = os.path.join(base, 'llama3help_test_sen.csv')
            llm_file_more = os.path.join(base, 'llama3help_test_sen_more.csv')
        elif type == 'train':''')
path = repo / 'data/process_esc_csr.py'
text = path.read_text()
start = text.index('        if len(llm_rows) == 0 or len(llm_rows2) == 0:')
end = text.index('    def get_event_index', start)
text = text[:start] + '''        if not llm_rows or not llm_rows2:
            raise FileNotFoundError(f'Missing context CSV for {type}: {llm_file}, {llm_file_more}')
        outputs = []
        for rows in (llm_rows, llm_rows2):
            matching = [r for r in rows[1:] if r[1] == doc_id]
            pairs = [p for r in matching for p in ast.literal_eval(r[5])]
            feature = next(f for f in self.features if f.doc_id == doc_id)
            assert pairs == [list(p) for p in feature.event_pairs], doc_id
            answers = [a for r in matching for a in ast.literal_eval(r[6])]
            assert len(answers) == pair_count, doc_id
            labels = torch.zeros(pair_count, len(sentences), dtype=torch.long, device='cuda')
            for i, answer in enumerate(answers):
                if answer != 'None':
                    ids = [int(x) for x in answer.split(',')]
                    assert all(0 <= x < len(sentences) for x in ids), doc_id
                    labels[i, ids] = 1
            outputs.append(labels)
        return outputs[0], outputs[1]
''' + text[end:]
text = text.replace("        if int(topic_id)>35:", "        if hasattr(batch[0], 'data_split'):\n            set_type = batch[0].data_split\n        elif int(topic_id)>35:")
text = text.replace("        assert (set_type in ['train', 'dev'])", "        assert (set_type in ['train', 'dev', 'test'])")
path.write_text(text)

edit('main.py', 'import time\n', 'import time\nimport json\n')
edit('main.py', '    # 5 folds\n', '''    # Fixed public-valid test split for MAVEN; ESL retains repository KFold.
    if args.dataset_type == 'MAVEN':
        test_features, test_dataset = processor.generate_dataloader('test')
        train_count = len(train_test_dataset)
        combined = train_test_features + test_features
        train_test_dataset = processor.convert_features_to_dataset(combined)
        fold_indices = [(np.arange(train_count), np.arange(train_count, len(combined)))]
    else:
        fold_indices = list(splits.split(train_test_dataset))
    if args.smoke:
        fold_indices = [(fold_indices[0][0][:2], fold_indices[0][1][:1])]
        valid_loader = DataLoader(Subset(dev_dataset, range(min(2, len(dev_dataset)))),
                                  batch_size=1, collate_fn=dev_dataset.collate_fn)
    split_ids = []
    for train_ids, test_ids in fold_indices:
        features = train_test_dataset.features
        split_ids.append({'train': [features[i].doc_id for i in train_ids],
                          'test': [features[i].doc_id for i in test_ids],
                          'dev': [f.doc_id for f in dev_features]})
        assert not set(split_ids[-1]['train']) & set(split_ids[-1]['test'])
        assert not set(split_ids[-1]['train']) & set(split_ids[-1]['dev'])
        assert not set(split_ids[-1]['test']) & set(split_ids[-1]['dev'])
    Path(args.run_dir, 'splits.json').write_text(json.dumps(split_ids, indent=2))
    # 5 folds
''')
edit('main.py', 'enumerate(splits.split(train_test_dataset))', 'enumerate(fold_indices)')
edit('main.py', '        best_valid_f1 = 0', '        best_valid_f1 = -1.0')
edit('main.py', "                            best_valid_test_cross = test_cross\n\n\n\n", '''                            best_valid_test_cross = test_cross
                            selected_epoch = epoch
                            torch.save({'model': model.state_dict(), 'args': vars(args),
                                        'epoch': epoch, 'dev_f1': valid_f1},
                                       Path(args.run_dir, f'fold_{fold+1}_best.pt'))
                            predictions = [{'doc_id': train_test_dataset.features[int(idx)].doc_id,
                                            'predicted': pred, 'gold': gold, 'rel_type': kind}
                                           for idx, pred, gold, kind in zip(test_idx, test_preds, test_golds, test_clabels)]
                            Path(args.run_dir, f'fold_{fold+1}_predictions.json').write_text(
                                json.dumps(predictions, default=lambda value: value.item()))

''')
edit('main.py', "        printlog('Fold {}: R", '''        with Path(args.run_dir, 'fold_metrics.jsonl').open('a') as record:
            record.write(json.dumps({'fold': fold + 1, 'selected_epoch': selected_epoch,
                                     'dev_f1': best_valid_f1, 'p': best_valid_test_p,
                                     'r': best_valid_test_r, 'f1': best_valid_test_f1,
                                     'intra': best_valid_test_intra, 'inter': best_valid_test_cross}) + '\\n')
        if args.smoke:
            checkpoint = torch.load(Path(args.run_dir, f'fold_{fold+1}_best.pt'), map_location=args.device)
            model.load_state_dict(checkpoint['model'])
            with torch.no_grad():
                reloaded = test_epoch(args, model, test_loader, selected_epoch, tokenizer)
            assert abs(reloaded[6] - best_valid_test_f1) < 1e-12
            printlog('SMOKE checkpoint reload predictions verified')
        printlog('Fold {}: R''')
edit('main.py', '    args = parse_args()', '''    args = parse_args()
    Path(args.run_dir).mkdir(parents=True, exist_ok=True)
    Path(args.run_dir, 'args.json').write_text(json.dumps(vars(args), indent=2))''')
for name in ['main.py', 'parameter.py', 'model/model.py', 'model/myGraph.py', 'data/process_esc_csr.py']:
    original = subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=repo)
    if b'\r\n' in original:
        file = repo / name
        file.write_bytes(file.read_text().replace('\n', '\r\n').encode())
with (root / 'repository.patch').open('w') as handle:
    subprocess.run(['git', 'diff'], cwd=repo, stdout=handle, check=True)
print('Patched repository; original scientific defaults retained', flush=True)
