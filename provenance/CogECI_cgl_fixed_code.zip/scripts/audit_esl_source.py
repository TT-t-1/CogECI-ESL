"""Compare the released iLIF cache to original ESL v0.9 mention-level gold links."""
import json
import subprocess
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from transformers import BertTokenizerFast
from prepare_data import load_features

root = Path(__file__).resolve().parents[1]
source = root / 'sources/EventStoryLine-complete'
tokenizer = BertTokenizerFast.from_pretrained('bert-base-uncased', local_files_only=True)
report = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip(),
          'counts': {}, 'documents': [], 'note': 'Audit only. The released cache is not relabeled or enlarged.'}
counts = Counter()
for split in ['train', 'dev']:
    features = load_features(root / 'data/esl' / f'EventStoryLine_bert_intra_and_inter_{split}_features.pkl')
    for f in features:
        xml = source / 'annotated_data/v0.9' / str(f.topic_id) / (f.doc_id + 'ecbplus.xml.xml')
        doc = ET.parse(xml).getroot()
        tokens = {t.attrib['t_id']: t for t in doc.findall('token')}
        by_sentence = {}
        for tid, token in tokens.items():
            by_sentence.setdefault(token.attrib['sentence'], []).append(tid)
        # Match exact token sequences rather than assuming raw sentence0 was discarded.
        sentence_lookup = {tuple(tokens[t].text for t in tids): (sid, tids) for sid, tids in by_sentence.items()}
        encoded_positions = {}
        unmatched_sentences = []
        for sid, sentence in enumerate(f.sentences):
            if tuple(sentence) not in sentence_lookup:
                unmatched_sentences.append({'sentence': sid, 'tokens': sentence})
                continue
            _, tids = sentence_lookup[tuple(sentence)]
            encoding = tokenizer(sentence, is_split_into_words=True)
            word_ids = encoding.word_ids()
            encoded_positions[sid] = (tids, word_ids)
        span_to_anchor = {}
        for markable in doc.find('Markables'):
            if not markable.tag.startswith(('ACTION', 'NEG_ACTION')):
                continue
            anchors = [a.attrib['t_id'] for a in markable.findall('token_anchor')]
            if not anchors:
                continue
            for sid, (tids, word_ids) in encoded_positions.items():
                if anchors[0] in tids:
                    indices = {tids.index(t) for t in anchors}
                    positions = [i for i, w in enumerate(word_ids) if w in indices]
                    span_to_anchor[(sid, positions[0], positions[-1] + 1)] = '_'.join(anchors)
                    break
        mapped = []
        unmapped = []
        for i, (sid, (a, b)) in enumerate(f.node_event):
            key = int(sid), int(a), int(b)
            mapped.append(span_to_anchor.get(key))
            if mapped[-1] is None:
                unmapped.append({'event': i, 'span': list(key)})
        # Keep mapping failures visible; do not infer a cause from an incomplete comparison.
        row = {'doc_id': f.doc_id, 'split': split, 'unmapped_events': unmapped,
               'unmatched_sentences': unmatched_sentences}
        counts['unmatched_cache_sentences'] += len(unmatched_sentences)
        gold_file = source / 'evaluation_format/full_corpus/v0.9/event_mentions_extended' / str(f.topic_id) / (f.doc_id + 'ecbplus.tab')
        if not gold_file.exists():
            assert not any(e.tag == 'PLOT_LINK' and e.get('relType') in ['PRECONDITION', 'FALLING_ACTION']
                           for e in doc.find('Relations')), f.doc_id
            gold_text = ''
            row['no_gold_file_and_no_direct_causal_links'] = True
        else:
            gold_text = gold_file.read_text()
        gold = {tuple(sorted(line.split('\t')[:2])) for line in gold_text.splitlines()
                if line.split('\t')[-1] in ['PRECONDITION', 'FALLING_ACTION']}
        counts['source_extended_positive_pairs'] += len(gold)
        counts['cache_positive_pairs'] += sum(t != 0 for t in f.target)
        counts['unmapped_cache_events'] += len(unmapped)
        if not unmapped:
            cached = {tuple(sorted([mapped[a], mapped[b]])) for (a, b), t in zip(f.event_pairs, f.target) if t}
            candidate = {tuple(sorted([mapped[a], mapped[b]])) for a, b in f.event_pairs}
            row.update(missing_from_cache=sorted(gold - cached), extra_in_cache=sorted(cached - gold),
                       gold_outside_candidate_set=sorted(gold - candidate))
            counts['missing_from_cache'] += len(gold - cached)
            counts['extra_in_cache'] += len(cached - gold)
            counts['gold_outside_candidate_set'] += len(gold - candidate)
        report['documents'].append(row)
report['counts'] = dict(counts)
report['mapping_limit'] = 'Missing/extra link counts compare only documents whose cached event spans all map exactly to raw v0.9. Other documents are listed without guessed mappings.'
(root / 'data/esl_source_audit.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report['counts'], indent=2), flush=True)
