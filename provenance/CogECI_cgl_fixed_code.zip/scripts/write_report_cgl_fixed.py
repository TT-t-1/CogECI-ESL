"""Report only classifier experiments trained with the selected CGL gradient fix."""
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import numpy as np

root = Path(__file__).resolve().parents[1]
completed, partial = [], []
for folder in sorted((root / 'runs-cgl-fixed').glob('*')):
    metrics = folder / 'fold_metrics.jsonl'
    if not metrics.exists() or not folder.name.startswith(('qwen7b_', 'llama8b_')):
        continue
    folds = [json.loads(line) for line in metrics.read_text().splitlines()]
    expected = 1 if '_maven_' in folder.name else 5
    status = json.loads((folder / 'status.json').read_text()) if (folder / 'status.json').exists() else {}
    entry = {'run': folder.name, 'folds': folds, 'status': status, 'expected_folds': expected}
    if len(folds) == expected and status.get('exit_code') == 0 and not status.get('thermal_stop'):
        entry['mean'] = {k: float(np.mean([f[k] for f in folds])) for k in ['p', 'r', 'f1']}
        for relation in ['intra', 'inter']:
            entry['mean'][relation] = {k: float(np.mean([f[relation][k] for f in folds])) for k in ['p', 'r', 'f1']}
        completed.append(entry)
    else:
        partial.append(entry)
states = {name: json.loads((root / f'{name}_cgl_fixed_pipeline_status.json').read_text())
          for name in ['qwen7b', 'llama8b'] if (root / f'{name}_cgl_fixed_pipeline_status.json').exists()}
report = {'version': 'user_selected_cgl_gradient_fix',
          'updated_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
          'complete_runs': completed, 'partial_runs': partial, 'pipeline_states': states,
          'changes': ['continuous cosine logits in context BCE for focal and CE', 'all parameters included in optimizer'],
          'not_applicable': ['paper training-threshold sweep: selected fix removes the hard threshold'],
          'paper_reference_f1_percent': {'llama8b_esl': 66.5, 'llama8b_maven': 58.9, 'qwen7b_esl': 65.4}}
(root / 'results_cgl_fixed.json').write_text(json.dumps(report, indent=2))
lines = ['# CGL 梯度修正版实验状态', '', report['updated_at'], '',
         '本结果只纳入用户指定修复后的新训练。旧 Qwen-plus 修改版、仓库原始行为版和合成标签检查均不计入。', '',
         '| 完成实验 | P | R | F1 |', '|---|---:|---:|---:|']
for entry in completed:
    m = entry['mean']
    lines.append(f'| {entry["run"]} | {m["p"]*100:.2f} | {m["r"]*100:.2f} | {m["f1"]*100:.2f} |')
if not completed:
    lines.append('| 尚无完整新结果 | — | — | — |')
lines += ['', '队列状态：', ''] + [f'- {name}: `{state["phase"]}`' for name, state in states.items()]
lines += ['', '该修复改变作者原始实现，不能称为逐字复现作者训练目标。阈值扫描不再适用于连续 CGL；其余约定实验继续。']
(root / 'RESULTS_cgl_fixed.md').write_text('\n'.join(lines) + '\n')
# Case comparisons use the disclosed no-SGM ablation, not an unrun iLIF baseline.
by_name = {entry['run']: entry for entry in completed}
if 'llama8b_esl_main' in by_name and 'llama8b_esl_without_sgm' in by_name:
    from prepare_data import load_features
    from transformers import BertTokenizer
    features = {f.doc_id: f for f in load_features(root / 'data/esl/EventStoryLine_bert_intra_and_inter_train_features.pkl')}
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased', local_files_only=True)
    cases = {}
    for fold in range(1, 6):
        main = json.loads((root / 'runs-cgl-fixed/llama8b_esl_main' / f'fold_{fold}_predictions.json').read_text())
        removed = json.loads((root / 'runs-cgl-fixed/llama8b_esl_without_sgm' / f'fold_{fold}_predictions.json').read_text())
        for a, b in zip(main, removed):
            assert a['doc_id'] == b['doc_id'] and a['gold'] == b['gold']
            for i, (gold, predicted, baseline, relation) in enumerate(zip(a['gold'], a['predicted'], b['predicted'], a['rel_type'])):
                kind = 'inter' if relation else 'intra'
                if kind in cases or (gold, predicted, baseline) != (1, 1, 0):
                    continue
                f = features[a['doc_id']]
                pair = f.event_pairs[i]
                triggers = []
                for node in pair:
                    sid, (start, end) = f.node_event[node]
                    triggers.append(tokenizer.decode(f.enc_input_ids[int(sid), int(start):int(end)]))
                cases[kind] = {'doc_id': f.doc_id, 'fold': fold, 'pair_index': i, 'events': triggers,
                               'sentences': [' '.join(s) for s in f.sentences],
                               'gold': gold, 'full_prediction': predicted, 'without_sgm_prediction': baseline,
                               'note': 'Our selected illustrative case; comparator is the no-SGM ablation, not paper iLIF.'}
    (root / 'cases_cgl_fixed.json').write_text(json.dumps(cases, ensure_ascii=False, indent=2))
print(json.dumps({'completed': len(completed), 'partial': len(partial), 'states': states}, indent=2))
