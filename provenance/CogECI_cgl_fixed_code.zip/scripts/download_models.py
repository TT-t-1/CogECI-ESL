"""Download the named original model; verify files against its pinned official Git tree."""
import argparse
import hashlib
import json
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--model', choices=['qwen7b', 'llama8b'], default='qwen7b')
args = parser.parse_args()
if args.model == 'qwen7b':
    spec = {'repo_id': 'Qwen/Qwen2.5-7B-Instruct',
            'revision': 'a09a35458c702b33eeacc393d103063234e8bc28',
            'mirror_repo': 'Qwen/Qwen2.5-7B-Instruct'}
    folder, manifest_name = 'qwen2.5-7b-instruct', 'qwen_download.json'
else:
    spec = {'repo_id': 'meta-llama/Meta-Llama-3-8B-Instruct',
            'revision': '8afb486c1db24fe5011ec46dfbe5b5dccdb575c2',
            'mirror_repo': 'modelscope/Meta-Llama-3-8B-Instruct'}
    folder, manifest_name = 'llama3-8b-instruct', 'llama_download.json'
with urllib.request.urlopen(f'https://huggingface.co/api/models/{spec["repo_id"]}/tree/{spec["revision"]}', timeout=30) as f:
    expected = json.load(f)
with urllib.request.urlopen(f'https://modelscope.cn/api/v1/models/{spec["mirror_repo"]}/repo/files?Revision=master&Recursive=false', timeout=30) as f:
    mirror = {item['Path']: item for item in json.load(f)['Data']['Files']}
path = root / 'models' / folder
path.mkdir(exist_ok=True, parents=True)

def hashes(file):
    sha = hashlib.sha256()
    git = hashlib.sha1(f'blob {file.stat().st_size}\0'.encode())
    with file.open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            sha.update(block)
            git.update(block)
    return sha.hexdigest(), git.hexdigest()

chunk_size = 64 * 1024 * 1024

def range_download(job):
    url, start, end, file = job
    if file.exists() and file.stat().st_size == end - start + 1:
        return
    for attempt in range(3):
        request = urllib.request.Request(url + f'&part={start}', headers={'Range': f'bytes={start}-{end}'})
        try:
            with urllib.request.urlopen(request, timeout=120) as source, file.open('wb') as output:
                assert source.status == 206 and source.headers['Content-Range'].startswith(f'bytes {start}-{end}/')
                while block := source.read(8 * 1024 * 1024):
                    output.write(block)
        except (urllib.error.URLError, ConnectionError, TimeoutError) as error:
            print('range network retry', start, attempt + 1, str(error), flush=True)
        if file.exists() and file.stat().st_size == end - start + 1:
            print('range complete', file.parent.name, start, end, flush=True)
            return
        print('incomplete range; retry', start, attempt + 1, flush=True)
        time.sleep(2)
    raise RuntimeError(f'Incomplete download range after 3 attempts: {file}: {start}-{end}')

def download(item):
    name = item['path']
    target = path / name
    meta = mirror[name]
    if 'lfs' in item:
        # The gated repository masks the raw SHA but publishes the Git LFS pointer's
        # Git object ID. Verify the mirror SHA/size by reconstructing that pointer.
        pointer = (f'version https://git-lfs.github.com/spec/v1\n'
                   f'oid sha256:{meta["Sha256"]}\nsize {meta["Size"]}\n').encode()
        assert hashlib.sha1(f'blob {len(pointer)}\0'.encode() + pointer).hexdigest() == item['oid'], name
        assert meta['Size'] == item['size'], name
    if target.exists():
        sha, git = hashes(target)
        if target.stat().st_size == item['size'] and (sha == meta['Sha256'] if 'lfs' in item else git == item['oid']):
            return {'file': name, 'sha256': sha, 'size': item['size'], 'official_git_blob': item['oid'], 'verified_against': 'HF pinned tree'}
    url = f'https://modelscope.cn/models/{spec["mirror_repo"]}/resolve/{meta["Revision"]}/{name}?download=true'
    temporary = target.with_suffix(target.suffix + '.part')
    print('downloading', name, item['size'], flush=True)
    if 'lfs' in item:
        # Single-stream throughput was severely uneven. Resume its contiguous prefix and
        # fetch the remainder in bounded ranges; the final full-file hash is mandatory.
        prefix = min(temporary.stat().st_size // chunk_size * chunk_size, item['size']) if temporary.exists() else 0
        chunks = path / '.ranges' / name
        chunks.mkdir(parents=True, exist_ok=True)
        jobs = [(url, start, min(start + chunk_size, item['size']) - 1, chunks / str(start))
                for start in range(prefix, item['size'], chunk_size)]
        with ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(range_download, jobs))
        with temporary.open('r+b' if temporary.exists() else 'wb') as output:
            output.truncate(prefix)
            output.seek(prefix)
            for _, start, _, chunk in jobs:
                with chunk.open('rb') as f:
                    while block := f.read(8 * 1024 * 1024):
                        output.write(block)
                chunk.unlink()
    else:
        with urllib.request.urlopen(url, timeout=120) as source, temporary.open('wb') as f:
            while block := source.read(8 * 1024 * 1024):
                f.write(block)
    sha, git = hashes(temporary)
    assert temporary.stat().st_size == item['size'], name
    assert sha == meta['Sha256'] if 'lfs' in item else git == item['oid'], name
    temporary.replace(target)
    print('verified', name, sha, flush=True)
    return {'file': name, 'sha256': sha, 'size': item['size'], 'official_git_blob': item['oid'], 'verified_against': 'HF pinned tree', 'source': url}

files = [item for item in expected if item['type'] == 'file' and
         (item['path'].endswith(('.json', '.safetensors', '.txt')) or item['path'] in ['LICENSE', 'USE_POLICY.md']
          or (args.model == 'qwen7b' and item['path'] == 'README.md'))]
verified = [download(item) for item in files]
(root / 'models' / manifest_name).write_text(json.dumps({**spec, 'path': str(path), 'files': verified}, indent=2))
print('Verified model download complete', path, flush=True)
