"""Collect completed experiment folds; keep fixtures and paper values out of actual results."""
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import numpy as np

root = Path(__file__).resolve().parents[1]
results = []
partial = []
for directory in sorted((root / 'runs').glob('*')):
    if directory.name.split('_')[0] not in ['qwen7b', 'llama8b']:
        continue
    file = directory / 'fold_metrics.jsonl'
    if not file.exists():
        continue
    folds = [json.loads(line) for line in file.read_text().splitlines()]
    expected = 1 if '_maven_' in directory.name else 5
    status = json.loads((directory / 'status.json').read_text()) if (directory / 'status.json').exists() else {}
    entry = {'run': directory.name, 'folds': folds, 'expected_folds': expected, 'status': status}
    if len(folds) == expected and status.get('exit_code') == 0 and not status.get('thermal_stop'):
        entry['mean'] = {k: float(np.mean([f[k] for f in folds])) for k in ['p', 'r', 'f1']}
        for relation in ['intra', 'inter']:
            entry['mean'][relation] = {k: float(np.mean([f[relation][k] for f in folds])) for k in ['p', 'r', 'f1']}
        results.append(entry)
    else:
        partial.append(entry)
states = {n: json.loads((root / f'{n}_pipeline_status.json').read_text())
          for n in ['qwen7b', 'llama8b'] if (root / f'{n}_pipeline_status.json').exists()}
report = {'updated_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
          'complete_runs': results, 'partial_runs': partial, 'pipeline_states': states,
          'paper_reference_f1_percent': {'llama8b_esl': 66.5, 'llama8b_maven': 58.9, 'qwen7b_esl': 65.4},
          'paper_reference_note': 'Paper main/ablation LLM is not explicitly stated; using Llama8B was our disclosed inference.',
          'limitations': ['repository thresholded CGL has no gradient',
                          'repository optimizer membership retained',
                          'ESL cache differs from paper counts',
                          'shared sen/sen_more labels and missing ablation implementations are disclosed adaptations']}
(root / 'results.json').write_text(json.dumps(report, indent=2))
lines = ['# CogECI 仓库优先复现状态', '', '更新时间：' + report['updated_at'], '',
         '完整指标只纳入已经成功完成的实验；合成标签运行检查不属于论文结果。', '',
         '| 已完成实验 | P | R | F1 |', '|---|---:|---:|---:|']
for entry in results:
    m = entry['mean']
    lines.append(f'| {entry["run"]} | {m["p"]*100:.2f} | {m["r"]*100:.2f} | {m["f1"]*100:.2f} |')
if not results:
    lines.append('| 尚无新的完整实验结果 | — | — | — |')
lines += ['', '当前队列：', '']
for name, state in states.items():
    lines.append(f'- {name}: `{state["phase"]}`')
lines += ['', '论文参考值为 ESL 66.5、MAVEN 58.9、Qwen7B ESL 65.4，不是本次实测结果。', '',
          '原仓库 CGL 硬阈值会切断梯度；β=0 和 β=6 的实测参数梯度完全相同。按用户要求保留仓库行为，因此 β、CGL 和上下文阈值实验不能验证论文声称的训练作用。', '',
          '详细依赖、设置来源和补充实现见 REPRODUCTION.md。此前 Qwen-plus 修改版结果单独保留。']
(root / 'RESULTS.md').write_text('\n'.join(lines) + '\n')
# Case comparisons use the disclosed no-SGM ablation, not an unrun iLIF baseline.
by_name = {entry['run']: entry for entry in results}
if 'llama8b_esl_main' in by_name and 'llama8b_esl_without_sgm' in by_name:
    from prepare_data import load_features
    from transformers import BertTokenizer
    features = {f.doc_id: f for f in load_features(root / 'data/esl/EventStoryLine_bert_intra_and_inter_train_features.pkl')}
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased', local_files_only=True)
    cases = {}
    for fold in range(1, 6):
        main = json.loads((root / 'runs/llama8b_esl_main' / f'fold_{fold}_predictions.json').read_text())
        removed = json.loads((root / 'runs/llama8b_esl_without_sgm' / f'fold_{fold}_predictions.json').read_text())
        for a, b in zip(main, removed):
            assert a['doc_id'] == b['doc_id'] and a['gold'] == b['gold']
            for i, (gold, predicted, baseline, relation) in enumerate(zip(a['gold'], a['predicted'], b['predicted'], a['rel_type'])):
                kind = 'inter' if relation else 'intra'
                if kind in cases or (gold, predicted, baseline) != (1, 1, 0):
                    continue
                f = features[a['doc_id']]
                pair = f.event_pairs[i]
                triggers = []
                for node in pair:
                    sid, (start, end) = f.node_event[node]
                    triggers.append(tokenizer.decode(f.enc_input_ids[int(sid), int(start):int(end)]))
                cases[kind] = {'doc_id': f.doc_id, 'fold': fold, 'pair_index': i, 'events': triggers,
                               'sentences': [' '.join(s) for s in f.sentences],
                               'gold': gold, 'full_prediction': predicted, 'without_sgm_prediction': baseline,
                               'note': 'Our selected illustrative case; comparator is the no-SGM ablation, not paper iLIF.'}
    (root / 'cases.json').write_text(json.dumps(cases, ensure_ascii=False, indent=2))
print(json.dumps({'complete_runs': len(results), 'partial_runs': len(partial), 'states': states}, indent=2))
