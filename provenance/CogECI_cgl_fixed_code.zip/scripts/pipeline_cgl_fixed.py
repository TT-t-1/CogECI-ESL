"""Sequential authorized experiments. Each GPU child is owned by the thermal guard."""
import argparse
import fcntl
import json
import os
import subprocess
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
train_python = root.parent / 'env/bin/python'
llm_python = root / 'llm-env/bin/python'
parser = argparse.ArgumentParser()
parser.add_argument('--model', choices=['qwen7b', 'llama8b'], required=True)
args = parser.parse_args()
name = args.model
state_path = root / f'{name}_cgl_fixed_pipeline_status.json'

def state(phase, **extra):
    state_path.write_text(json.dumps({'phase': phase, 'model': name, 'updated_unix': time.time(), **extra}, indent=2))
    print(phase, extra, flush=True)

def guarded(stage, command, environment=None, cwd=None):
    directory = root / 'runs-cgl-fixed' / f'{name}_{stage}'
    completed = directory / 'status.json'
    if completed.exists():
        previous = json.loads(completed.read_text())
        if previous['exit_code'] == 0 and not previous['thermal_stop']:
            return
        raise RuntimeError(f'{stage} previously failed; inspect before any explicit retry')
    state(stage, run_dir=str(directory))
    process = subprocess.run(['python3', str(root / 'scripts/guard.py'), str(directory), *map(str, command)],
                             env=environment, cwd=cwd)
    status = json.loads(completed.read_text()) if completed.exists() else {}
    if process.returncode:
        state('stopped', failed_stage=stage, **status)
        raise SystemExit(process.returncode)

def labels(dataset):
    for smoke in [True, False]:
        command = [llm_python, '-u', root / 'scripts/label_local.py', '--model', model,
                   '--name', name, '--dataset', dataset]
        if smoke:
            command.append('--smoke')
        guarded(f'{dataset}_labels_{"smoke" if smoke else "full"}', command)
        report = json.loads((root / 'labels' / name / dataset /
                             ('smoke' if smoke else 'full') / 'summary.json').read_text())
        if smoke:
            events = [json.loads(line) for line in (root / 'labels' / name / dataset / 'smoke/responses.jsonl').read_text().splitlines()]
            averages = {stage: sum(r['seconds'] for r in events if r['stage'] == stage) /
                        max(1, sum(r['stage'] == stage for r in events)) for stage in ['event', 'context']}
            audit = json.loads((root / 'data/audit.json').read_text())['ESL' if dataset == 'esl' else 'MAVEN']
            event_count = sum(audit[s]['events'] for s in ['train', 'dev'])
            pair_count = sum(audit[s]['positive'] for s in ['train', 'dev'])
            estimate = {'measured_seconds_per_call': averages, 'event_calls': event_count,
                        'context_calls': pair_count,
                        'estimated_generation_hours': (event_count * averages['event'] + pair_count * averages['context']) / 3600,
                        'limit': 'rough estimate from short and long documents; not a completion-time guarantee'}
            (root / f'{name}_{dataset}_estimate.json').write_text(json.dumps(estimate, indent=2))
            print('ESTIMATE', estimate, flush=True)

def train(dataset, suffix, extra=()):
    environment = os.environ.copy()
    environment.update(COGECI_DATA_DIR=str(root / 'labels' / name / dataset / 'full'), HF_HUB_OFFLINE='1')
    directory = root / 'runs-cgl-fixed' / f'{name}_{dataset}_{suffix}'
    command = [train_python, '-u', 'main.py', '--run_dir', directory,
               '--dataset_type', 'EventStoryLine' if dataset == 'esl' else 'MAVEN',
               '--cache_path', root / 'data' / dataset, '--model_name', 'bert-base-uncased',
               '--seed', '209', '--epoch', '30', '--beta_intra', '.3', '--beta_inter', '.7',
               '--method', f'{name}_{dataset}_{suffix}', *extra]
    guarded(f'{dataset}_{suffix}', command, environment, root / 'CogECI-cgl-fixed')
    subprocess.run([str(train_python), str(root / 'scripts/write_report_cgl_fixed.py')], check=True)

try:
    if name == 'qwen7b':
        state('waiting_for_verified_model_download')
        while not (root / 'models/qwen_download.json').exists():
            pid = int((root / 'model_download.pid').read_text())
            proc = Path(f'/proc/{pid}/stat')
            if not proc.exists() or proc.read_text().split()[2] == 'Z':
                raise RuntimeError('Model downloader exited without a verified manifest; inspect download log')
            time.sleep(10)
        model = root / 'models/qwen2.5-7b-instruct'
    else:
        model = root / 'models/llama3-8b-instruct'
        if not (root / 'models/llama_download.json').exists():
            download_pid_file = root / 'llama_model_download.pid'
            if not download_pid_file.exists():
                state('blocked_model_access', reason='No verified original Llama3-8B download is available')
                raise SystemExit(2)
            state('waiting_for_verified_model_download', source='ModelScope same original model')
            while not (root / 'models/llama_download.json').exists():
                pid = int(download_pid_file.read_text())
                proc = Path(f'/proc/{pid}/stat')
                if not proc.exists() or proc.read_text().split()[2] == 'Z':
                    raise RuntimeError('Llama downloader exited without a verified manifest; inspect llama_model_download.log')
                time.sleep(10)
    state('waiting_for_gpu1_queue')
    gpu_lock = (root / 'gpu1.lock').open('a')
    fcntl.flock(gpu_lock.fileno(), fcntl.LOCK_EX)
    labels('esl')
    train('esl', 'main')
    if name == 'llama8b':
        labels('maven')
        train('maven', 'main')
        for suffix, flags in [('without_cgl', ['--context_beta', '0']), ('without_sgm', ['--no_sgm']),
                              ('shared_dscrm', ['--shared_dscrm'])]:
            train('esl', suffix, flags)
        for beta in ['0.1', '0.8', '2', '4', '8', '10']:
            train('esl', 'beta_' + beta, ['--context_beta', beta])
        for layers in ['1', '3', '4']:
            train('esl', 'sgm_layers_' + layers, ['--sgm_layers', layers])
        for operator in ['gcn', 'hypergraph', 'transformer']:
            train('esl', 'graph_' + operator, ['--graph_encoder', operator])
    state('completed')
    subprocess.run([str(train_python), str(root / 'scripts/write_report_cgl_fixed.py')], check=True)
except Exception as error:
    state('failed', error=str(error))
    raise
