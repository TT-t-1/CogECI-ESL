# -*- coding: utf-8 -*-
import time
import json
import numpy as np
import os
# os.environ['CUDA_VISIBLE_DEVICES'] = '3'
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Subset, RandomSampler, SequentialSampler, DataLoader
import logging
import tqdm
from datetime import datetime
from data import ESC_processor
from data import all_processor
from utils import transfor3to2, compute_f1, setup_seed, calculate
from pathlib import Path
from sklearn.model_selection import KFold
from transformers import AdamW, get_linear_schedule_with_warmup
from transformers import BertConfig, BertTokenizer
from transformers import RobertaConfig,RobertaTokenizer
from parameter import parse_args
from model import bertCSRModel

logger = logging.getLogger(__name__)

MODEL_CLASSES = {
    'bert': (BertConfig, bertCSRModel, BertTokenizer),
    # 'bert': (RobertaConfig, bertCSRModel, RobertaTokenizer)
}
class CTB_features(object):
    def __init__(self, doc_id,
                 enc_text, enc_tokens, sentences,
                 enc_input_ids, enc_mask_ids, node_event,
                 t1_pos, t2_pos, mh_self_attention_mask, target, rel_type, event_pairs
                 ):
        self.doc_id = doc_id
        self.enc_text = enc_text
        self.enc_tokens = enc_tokens
        self.sentences = sentences
        self.enc_input_ids = enc_input_ids
        self.enc_mask_ids = enc_mask_ids
        self.node_event = node_event
        self.t1_pos = t1_pos
        self.t2_pos = t2_pos
        self.mh_self_attention_mask = mh_self_attention_mask
        self.target = target
        self.rel_type = rel_type
        self.event_pairs = event_pairs
class all_features(object):
    def __init__(self, doc_id,
                 enc_text, enc_tokens, sentences,
                 enc_input_ids, enc_mask_ids, node_event,
                 t1_pos, t2_pos, mh_self_attention_mask, target, rel_type, event_pairs
                 ):
        self.doc_id = doc_id
        self.enc_text = enc_text
        self.enc_tokens = enc_tokens
        self.sentences = sentences
        self.enc_input_ids = enc_input_ids
        self.enc_mask_ids = enc_mask_ids
        self.node_event = node_event
        self.t1_pos = t1_pos
        self.t2_pos = t2_pos
        self.mh_self_attention_mask = mh_self_attention_mask
        self.target = target
        self.rel_type = rel_type
        self.event_pairs = event_pairs
class ESC_features(object):
    def __init__(self, topic_id, doc_id,
                 enc_text, enc_tokens, sentences,
                 enc_input_ids, enc_mask_ids, node_event,
                 t1_pos, t2_pos, target, rel_type, event_pairs
                 ):
        # self.topic_id = topic_id
        self.doc_id = doc_id
        # self.enc_text = enc_text
        # self.enc_tokens = enc_tokens
        # self.sentences = sentences
        self.enc_input_ids = enc_input_ids
        self.enc_mask_ids = enc_mask_ids
        self.node_event = node_event
        self.t1_pos = t1_pos
        self.t2_pos = t2_pos
        self.target = target
        self.rel_type = rel_type
        self.event_pairs = event_pairs
def compute_kl_loss(p, q, pad_mask=None):
    p_loss = F.kl_div(F.log_softmax(p, dim=-1), F.softmax(q, dim=-1), reduction='none')
    q_loss = F.kl_div(F.log_softmax(q, dim=-1), F.softmax(p, dim=-1), reduction='none')

    # pad_mask is for seq-level tasks
    if pad_mask is not None:
        p_loss.masked_fill_(pad_mask, 0.)
        q_loss.masked_fill_(pad_mask, 0.)

    # You can choose whether to use function "sum" and "mean" depending on your task
    p_loss = p_loss.sum()
    q_loss = q_loss.sum()

    loss = (p_loss + q_loss) / 2
    return loss
def train_epoch(args, model, train_loader, optimizer, scheduler, epoch,tokenizer):
    train_loss = []
    predicted_all = []
    gold_all = []
    clabel_all = []
    model.train()
    progress = tqdm.tqdm(total=len(train_loader), ncols=75,
                         desc='Train {}'.format(epoch))
    for step, batch in enumerate(train_loader):
        progress.update(1)
        inputs = {'enc_input_ids': batch[0].to('cuda'),
                  'enc_mask_ids': batch[1].to('cuda'),
                  'node_event': batch[2],
                  't1_pos': batch[3],
                  't2_pos': batch[4],
                  'target': batch[5],
                  'rel_type': batch[6],
                  'event_pairs': batch[7],
                  'all_senlable': batch[8],
                  "all_senlable2": batch[9],
                  'type':'train',
                  'doc_id':batch[10],
                  'tokenizer':tokenizer
                  }
        loss, opt= model(**inputs)
        # loss2, opt= model(**inputs)
        # ce_batch_loss = (loss + loss2) / 2
        # kl_batch_loss = compute_kl_loss(loss, loss2)
        # cl_loss = ce_batch_loss + 4 * kl_batch_loss
        # loss = cl_loss
        loss = loss / args.gradient_accumulation_steps
        loss.backward()
        if step % args.gradient_accumulation_steps == 0:
            nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
            optimizer.step()
            scheduler.step()
            model.zero_grad()

        train_loss.append(loss.item())
        predicted_ = torch.argmax(opt, -1)
        predicted_ = list(predicted_.cpu().numpy())
        gold_ = [t for bt in inputs['target'] for t in bt]
        clabel = [t for bt in inputs['rel_type'] for t in bt]
        # transform the three classification results predicted by the model to Causality Existence Identification and Causality Direction Identification results
        # predicted: the Identification Result of Causality Direction(we calculate the micro-averaged results for Precision, Recall, and F1-score specifically for the CAUSE and EFFECT classes)
        gold, predicted = transfor3to2(gold_, predicted_)
        gold_all += gold
        predicted_all += predicted
        clabel_all += clabel
        p, r, f1 = compute_f1(gold_all, predicted_all, logger)
        if step % args.logging_steps == 0:
            printlog('Step {}: Train Loss {} P {:.4f} R {:.4f} F1 {:.4f}'.format(step, np.mean(train_loss), p, r, f1))
    progress.close()
    p, r, f1 = compute_f1(gold_all, predicted_all, logger)
    _, _, _, intra, cross = calculate(gold_all, predicted_all, clabel_all, epoch, printlog)

    return np.mean(train_loss), r, p, f1, intra, cross

def test_epoch(args, model, test_loader,epoch,tokenizer):
    test_loss = []
    predicted_all = []
    predicted_all1_2 = []
    predicted_all2_1 = []
    gold_all = []
    gold_all1 = []
    clabel_all = []
    clabel_all1 = []
    preds = []
    preds1_2 = []
    preds2_1 = []
    golds = []
    golds1 = []
    clabels = []
    clabels1 = []
    model.eval()
    for batch in test_loader:
        inputs = {'enc_input_ids': batch[0].to('cuda'),
                  'enc_mask_ids': batch[1].to('cuda'),
                  'node_event': batch[2],
                  't1_pos': batch[3],
                  't2_pos': batch[4],
                  'target': batch[5],
                  'rel_type': batch[6],
                  'event_pairs': batch[7],
                  'all_senlable': batch[8],
                  "all_senlable2": batch[9],
                  'type':'test',
                  'doc_id':batch[10],
                  'tokenizer': tokenizer
                  }
        with torch.no_grad():  # 禁用梯度计算，节省内存和加快推理速度
            loss, opt = model(**inputs)
            loss2, opt = model(**inputs)
            ce_batch_loss = (loss + loss2) / 2
            kl_batch_loss = compute_kl_loss(loss, loss2)
            cl_loss = ce_batch_loss + 4 * kl_batch_loss
            loss = cl_loss
        test_loss.append(loss.item())
        gold_ = [t for bt in inputs['target'] for t in bt]
        clabel = [t for bt in inputs['rel_type'] for t in bt]
        predicted_ = torch.argmax(opt, -1)
        predicted_ = list(predicted_.cpu().numpy())
        gold, predicted = transfor3to2(gold_, predicted_)
        predicted_all += predicted
        preds.append(predicted)
        gold_all += gold
        clabel_all += clabel
        golds.append(gold)
        clabels.append(clabel)

    p, r, f1 = compute_f1(gold_all, predicted_all, logger)
    _, _, _, intra, cross = calculate(gold_all, predicted_all, clabel_all, epoch, printlog)

    return preds, golds, clabels, np.mean(test_loss), r, p, f1, intra, cross

def valid_epoch(args, model, valid_loader,epoch,tokenizer):
    valid_loss = []
    predicted_all = []
    gold_all = []
    clabel_all = []
    model.eval()
    for batch in valid_loader:
        inputs = {'enc_input_ids': batch[0].to('cuda'),
                  'enc_mask_ids': batch[1].to('cuda'),
                  'node_event': batch[2],
                  't1_pos': batch[3],
                  't2_pos': batch[4],
                  'target': batch[5],
                  'rel_type': batch[6],
                  'event_pairs': batch[7],
                  'all_senlable': batch[8],
                  "all_senlable2": batch[9],
                  'type': 'dev',
                  'doc_id':batch[10],
                  'tokenizer':tokenizer
                  }

        loss, opt= model(**inputs)
        # loss2, opt = model(**inputs)
        # ce_batch_loss = (loss + loss2) / 2
        # kl_batch_loss = compute_kl_loss(loss, loss2)
        # cl_loss = ce_batch_loss + 4 * kl_batch_loss
        # loss = cl_loss
        valid_loss.append(loss.item())
        predicted_ = torch.argmax(opt, -1)
        predicted_ = list(predicted_.cpu().numpy())
        gold_ = [t for bt in inputs['target'] for t in bt]
        clabel = [t for bt in inputs['rel_type'] for t in bt]
        # transform the three classification results predicted by the model to Causality Existence Identification and Causality Direction Identification results
        # predicted: the Identification Result of Causality Direction(we calculate the micro-averaged results for Precision, Recall, and F1-score specifically for the CAUSE and EFFECT classes)
        gold, predicted = transfor3to2(gold_, predicted_)
        predicted_all += predicted
        gold_all += gold
        clabel_all += clabel
    p, r, f1 = compute_f1(gold_all, predicted_all, logger)
    _, _, _, intra, cross = calculate(gold_all, predicted_all, clabel_all, epoch, printlog)
    return np.mean(valid_loss), r, p, f1, intra, cross

def cross_validation(args, model_class, processor,tokenizer):
    # Divide the training data into 5 folds randomly.
    splits = KFold(n_splits=args.k_fold, shuffle=True, random_state=args.seed)
    printlog("train dataloader generation")
    train_test_features, train_test_dataset = processor.generate_dataloader('train')
    # dev data
    printlog("dev dataloader generation")
    dev_features, dev_dataset = processor.generate_dataloader('dev')
    valid_loader = DataLoader(dev_dataset, sampler=SequentialSampler(dev_dataset), batch_size=args.batch_size, collate_fn=dev_dataset.collate_fn)

    avg_test_f1, avg_test_r, avg_test_p, avg_test_intra_p, avg_test_intra_r, avg_test_intra_f1, avg_test_cross_p, avg_test_cross_r, avg_test_cross_f1 = [], [], [], [], [], [], [], [], []
    # Fixed public-valid test split for MAVEN; ESL retains repository KFold.
    if args.dataset_type == 'MAVEN':
        test_features, test_dataset = processor.generate_dataloader('test')
        train_count = len(train_test_dataset)
        combined = train_test_features + test_features
        train_test_dataset = processor.convert_features_to_dataset(combined)
        fold_indices = [(np.arange(train_count), np.arange(train_count, len(combined)))]
    else:
        fold_indices = list(splits.split(train_test_dataset))
    if args.smoke:
        fold_indices = [(fold_indices[0][0][:2], fold_indices[0][1][:1])]
        valid_loader = DataLoader(Subset(dev_dataset, range(min(2, len(dev_dataset)))),
                                  batch_size=1, collate_fn=dev_dataset.collate_fn)
    split_ids = []
    for train_ids, test_ids in fold_indices:
        features = train_test_dataset.features
        split_ids.append({'train': [features[i].doc_id for i in train_ids],
                          'test': [features[i].doc_id for i in test_ids],
                          'dev': [f.doc_id for f in dev_features]})
        assert not set(split_ids[-1]['train']) & set(split_ids[-1]['test'])
        assert not set(split_ids[-1]['train']) & set(split_ids[-1]['dev'])
        assert not set(split_ids[-1]['test']) & set(split_ids[-1]['dev'])
    Path(args.run_dir, 'splits.json').write_text(json.dumps(split_ids, indent=2))
    # 5 folds
    for fold, (train_idx, test_idx) in enumerate(fold_indices):
        printlog("Fold {}".format(fold + 1))
        train_dataset = Subset(train_test_dataset, train_idx)
        test_dataset = Subset(train_test_dataset, test_idx)
        train_loader = DataLoader(train_dataset, batch_size=args.batch_size, sampler=RandomSampler(train_dataset),
                                  collate_fn=train_test_dataset.collate_fn)
        test_loader = DataLoader(test_dataset, batch_size=1, sampler=SequentialSampler(test_dataset),
                                 collate_fn=train_test_dataset.collate_fn)
        model = model_class(args).to(args.device)
        model.to(args.device)
        no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
        other_parameters = [(n, p) for n, p in model.named_parameters()
                            if not n.startswith('pretrained_model.')]
        optimizer_grouped_parameters = [
            {'params': [p for n, p in model.pretrained_model.named_parameters() if not any(nd in n for nd in no_decay)],
             'weight_decay': args.weight_decay, 'lr': args.t_lr},
            {'params': [p for n, p in model.pretrained_model.named_parameters() if any(nd in n for nd in no_decay)],
             'weight_decay': 0.0, 'lr': args.t_lr},
            {'params': [p for n, p in other_parameters if not any(nd in n for nd in no_decay)],
             'weight_decay': args.weight_decay},
            {'params': [p for n, p in other_parameters if any(nd in n for nd in no_decay)],
             'weight_decay': 0.0}
        ]

        optimizer = AdamW(optimizer_grouped_parameters, lr=args.lr, eps=args.adam_epsilon)
        total_steps = len(train_loader) * args.epoch
        scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=total_steps * args.warm_up_ratio,
                                                    num_training_steps=total_steps)
        best_valid_f1 = -1.0
        best_valid_test_preds, best_valid_test_golds, best_valid_test_f1, best_valid_test_r, best_valid_test_p = 0, 0, 0, 0, 0
        for epoch in range(1, args.epoch + 1):
            model.zero_grad()
            train_loss, train_r, train_p, train_f1, train_intra, train_cross = train_epoch(args, model, train_loader, optimizer, scheduler, epoch,tokenizer)
            printlog('Epoch{}: Train Loss {} R {} P {} F {}'.format(epoch, train_loss, train_r, train_p, train_f1))
            model.eval()
            with torch.no_grad():
                if epoch % args.test_epoch == 0:
                    test_preds, test_golds, test_clabels, test_loss, test_r, test_p, test_f1, test_intra, test_cross= test_epoch(args, model, test_loader,epoch,tokenizer)

                    printlog('Epoch{}: Test Loss {} R {} P {} F {} intra{} cross{}'.format(epoch, test_loss, test_r, test_p, test_f1, test_intra, test_cross))

                if epoch % args.valid_epoch == 0:
                    valid_loss, valid_r, valid_p, valid_f1, valid_intra, valid_cross = valid_epoch(args, model, valid_loader, epoch,tokenizer)
                    printlog('Epoch{}: Valid Loss {} R {} P {} F {} intra{} cross{}'.format(epoch, valid_loss, valid_r, valid_p, valid_f1, valid_intra, valid_cross))
                    if args.dataset_type=='CTB':
                        if valid_intra['f1'] >= best_valid_f1:
                            best_valid_f1 = valid_intra['f1']
                            best_valid_test_f1 = test_f1
                            best_valid_test_r = test_r
                            best_valid_test_p = test_p
                            best_valid_test_intra = test_intra
                            best_valid_test_cross = test_cross
                    else:
                        if valid_f1 >= best_valid_f1:
                            best_valid_f1 = valid_f1
                            best_valid_test_f1 = test_f1
                            best_valid_test_r = test_r
                            best_valid_test_p = test_p
                            best_valid_test_intra = test_intra
                            best_valid_test_cross = test_cross
                            selected_epoch = epoch
                            torch.save({'model': model.state_dict(), 'args': vars(args),
                                        'epoch': epoch, 'dev_f1': valid_f1},
                                       Path(args.run_dir, f'fold_{fold+1}_best.pt'))
                            predictions = [{'doc_id': train_test_dataset.features[int(idx)].doc_id,
                                            'predicted': pred, 'gold': gold, 'rel_type': kind}
                                           for idx, pred, gold, kind in zip(test_idx, test_preds, test_golds, test_clabels)]
                            Path(args.run_dir, f'fold_{fold+1}_predictions.json').write_text(
                                json.dumps(predictions, default=lambda value: value.item()))

        with Path(args.run_dir, 'fold_metrics.jsonl').open('a') as record:
            record.write(json.dumps({'fold': fold + 1, 'selected_epoch': selected_epoch,
                                     'dev_f1': best_valid_f1, 'p': best_valid_test_p,
                                     'r': best_valid_test_r, 'f1': best_valid_test_f1,
                                     'intra': best_valid_test_intra, 'inter': best_valid_test_cross}) + '\n')
        if args.smoke:
            checkpoint = torch.load(Path(args.run_dir, f'fold_{fold+1}_best.pt'), map_location=args.device)
            model.load_state_dict(checkpoint['model'])
            with torch.no_grad():
                reloaded = test_epoch(args, model, test_loader, selected_epoch, tokenizer)
            assert abs(reloaded[6] - best_valid_test_f1) < 1e-12
            printlog('SMOKE checkpoint reload predictions verified')
        printlog('Fold {}: R {} P {} F {} intra{} cross{}'.format(fold + 1, best_valid_test_r, best_valid_test_p, best_valid_test_f1, best_valid_test_intra, best_valid_test_cross))
        avg_test_f1.append(best_valid_test_f1)
        avg_test_r.append(best_valid_test_r)
        avg_test_p.append(best_valid_test_p)
        avg_test_intra_p.append(best_valid_test_intra['p'])
        avg_test_intra_r.append(best_valid_test_intra['r'])
        avg_test_intra_f1.append(best_valid_test_intra['f1'])
        avg_test_cross_p.append(best_valid_test_cross['p'])
        avg_test_cross_r.append(best_valid_test_cross['r'])
        avg_test_cross_f1.append(best_valid_test_cross['f1'])

    printlog("\n-------------------------Causality Direction Identification-------------------------\n")
    printlog("--------  \t Intra: P {} R {} F1 {} \n\t Cross: P {} R {} F1 {}  \n\t 5-Fold Avg: P {} R {} F1 {}---------".format(np.mean(avg_test_intra_p), np.mean(avg_test_intra_r), np.mean(avg_test_intra_f1), np.mean(avg_test_cross_p), np.mean(avg_test_cross_r),
                                                                                                                  np.mean(avg_test_cross_f1), np.mean(avg_test_p), np.mean(avg_test_r), np.mean(avg_test_f1)))
    # printlog("\n-------------------------Causality Direction Identification1_2-------------------------\n")
    # printlog("--------  \t Intra: P {} R {} F1 {} \n\t Cross: P {} R {} F1 {}  \n\t 5-Fold Avg: P {} R {} F1 {}---------".format(np.mean(avg_test_intra_p1), np.mean(avg_test_intra_r1), np.mean(avg_test_intra_f11), np.mean(avg_test_cross_p1), np.mean(avg_test_cross_r1),
    #                                                                                                               np.mean(avg_test_cross_f11), np.mean(avg_test_p1), np.mean(avg_test_r1), np.mean(avg_test_f11)))
    # printlog("\n-------------------------Causality Direction Identification2_1-------------------------\n")
    # printlog("--------  \t Intra: P {} R {} F1 {} \n\t Cross: P {} R {} F1 {}  \n\t 5-Fold Avg: P {} R {} F1 {}---------".format(np.mean(avg_test_intra_p2), np.mean(avg_test_intra_r2), np.mean(avg_test_intra_f12), np.mean(avg_test_cross_p2), np.mean(avg_test_cross_r2),
    #                                                                                                               np.mean(avg_test_cross_f12), np.mean(avg_test_p2), np.mean(avg_test_r2), np.mean(avg_test_f12)))

    # Tips: Another average F1: The final F1 value can be calculated according to F1=2*P*R/(P+R) by the final P value and final R value

def printlog(message: object, printout: object = True) -> object:
    message = '{}: {}'.format(datetime.now(), message)
    if printout:
        print(message)
    logger.info(message)

def main():
    args = parse_args()
    args.implementation = 'user_selected_cgl_gradient_fix'
    if args.context_threshold != '1/n':
        raise ValueError('The selected continuous CGL fix has no training threshold; this sweep is undefined.')
    Path(args.run_dir).mkdir(parents=True, exist_ok=True)
    Path(args.run_dir, 'args.json').write_text(json.dumps(vars(args), indent=2))
    torch.cuda.empty_cache()
    args.device = None

    if not args.disable_cuda and torch.cuda.is_available():
        args.device = torch.device('cuda')
    else:
        args.device = torch.device('cpu')

    t = time.strftime('%Y-%m-%d %H_%M_%S', time.localtime())
    args.log = Path(f"./logout/seed:{args.seed}")
    args.log.mkdir(exist_ok=True, parents=True)

    args.log = str(args.log) + '/t_lr' + str(args.t_lr) + 'lr' + str(args.lr) + t + str(args.method)+'.txt'

    for name in logging.root.manager.loggerDict:
        if 'transformers' in name:
            logging.getLogger(name).setLevel(logging.CRITICAL)

    logging.basicConfig(format='%(message)s', level=logging.INFO,
                        filename=args.log,
                        filemode='w')

    setup_seed(args.seed)

    config_class, eci_model_class, tokenizer_class = MODEL_CLASSES[args.model_type]

    tokenizer = tokenizer_class.from_pretrained(args.model_name)
    # tokenizer.add_tokens(['<t>', '</t>'])
    if args.dataset_type=='all':
        processor = all_processor(args, tokenizer, printlog)
    else:
        processor = ESC_processor(args, tokenizer, printlog)

    # processor = MAVEN_processor(args, tokenizer, printlog)

    printlog("Training/evaluation parameters :{}".format(args))
    cross_validation(args, eci_model_class, processor,tokenizer)

if __name__ == "__main__":
    main()